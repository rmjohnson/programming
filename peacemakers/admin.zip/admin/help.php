<?php 
	include("../connect.php");
	$result = mysql_query("SELECT * FROM help") or die(mysql_error());
	$row = mysql_fetch_array($result);
?>
<html>
	<head>
		<title>Edit the Help Page</title>
	</head>
	<body>
		<center>
		<form action="confirm.php" method="post">
			Title:<input type="text" name="title" value="<?php echo $row['title']; ?>"><br />
			Author:<input type="text" name="author" value="<?php echo $row['author']; ?>"><br />
			Content:<br /><textarea name="content" cols="100" rows="25"><?php echo $row['content']; ?></textarea><br />
			<input type="hidden" name="page" value="help">
			<input type="submit" name="submit" value="Submit!">
		</form>
		</center>
	</body>
</html>