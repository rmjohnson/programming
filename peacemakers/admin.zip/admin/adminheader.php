<?php
	require("../connect.php");
?>
<html>
	<head>
		<title>Admin</title>
		<link rel="stylesheet" type="text/css" href="../style.css" />
		<script type="text/javascript" type="text/javascript" src="scripts/wysiwyg.js"></script>  
		<script type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
		<script type="text/javascript">
			WYSIWYG.attach('all', full);
		</script>
	</head>
	<body>