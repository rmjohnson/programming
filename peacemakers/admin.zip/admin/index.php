<html>
	<head>
		<title>Admin</title>
		<link rel="stylesheet" type="text/css" href="../style.css" />
	</head>
	<body>
	<div id="content">
		<h3>What would you like to do?</h3>
		<ul>
			<!--<li><a href="help.php">Edit the help page</a></li>-->
			<li><a href="overview.php">Edit the overview pages</a></li>
			<li><a href="news.php">Update the peacemaking thoughts page</a></li>
			<li><a href="events.php">Update the events page</a></li>
		</ul>
	</div>
	<body>
</html>